import serial #Import the pyserial module
import matplotlib.pyplot as plt  #Import the matplotlib module
import scipy.signal #Import signal processing module

SAMPLE_SIZE = 100; # Number of samples in the plots
PORT = 'COM5' # Change this if necessary

count = 0
x_data=[] #Create empty arrays
y_data=[]
y_scaled_data=[]
data = serial.Serial(PORT, 9600) #Create a serial connection with arduino

while count < SAMPLE_SIZE:  #Only collect 1000 samples, or 5 seconds worth of data
	info = data.readline().decode("utf-8")
	myList = info.split('\t') #Make an array out of a line
	x_data.append(float(myList[0])/1000000)  #Add the time values to x_axis list
	y_data.append(float(myList[1]))  #Add the raw EMG values to y_axis list
	y_scaled_data.append((((float(myList[1]))*(3.3/1024))-1.5)/3.6)  #Create scaled array of values
	count = count + 1

first = plt.subplot(4,1,1) #Make two subplots, and start writing in first one
first.set_title("Unfiltered EMG Voltage")
plt.plot(x_data,y_scaled_data)  #plot the raw values x_data vs y_data
plt.ylabel("EMG Voltage (mV)") #Label Axes
plt.xlabel("Time(seconds)")

second = plt.subplot(4,1,2)  #Plot in second subplot
second.set_title("High-Pass Filter")
b_high, a_high = scipy.signal.butter(3,0.1,'high',analog=False) #Find coefficients for high-pass
y_high = scipy.signal.lfilter(b_high,a_high,y_scaled_data) #Apply high-pass filter
plt.plot(x_data,y_high)  #plot the raw values x_data vs y_scaled_data
plt.ylabel("EMG Voltage (mV)")#Label Axes
plt.xlabel("Time(seconds)")

third = plt.subplot(4,1,3)  #Plot in second subplots
third.set_title("Low-Pass Filter")
b_low, a_low = scipy.signal.butter(3,0.5,'low',analog=False) #Find coefficients for low-pass
y_low = scipy.signal.lfilter(b_low,a_low,y_scaled_data) #Apply high-pass filter
plt.plot(x_data,y_low)  #plot the raw values x_data vs y_scaled_data
plt.ylabel("EMG Voltage (mV)")#Label Axes
plt.xlabel("Time(seconds)")


fourth = plt.subplot(4,1,4)  #Plot in second subplot
fourth.set_title("Band-Pass Filter")
b_low, a_low = scipy.signal.butter(3,0.5,'low',analog=False) #Find coefficients for low-
y_both = scipy.signal.lfilter(b_low,a_low,y_high) #Apply low-pass filter to high-pass filtered data
plt.plot(x_data,y_both)  #plot the raw values x_data vs y_scaled_data
plt.ylabel("EMG Voltage (mV)") #Label Axes
plt.xlabel("Time(seconds)")
plt.tight_layout()
plt.show()
